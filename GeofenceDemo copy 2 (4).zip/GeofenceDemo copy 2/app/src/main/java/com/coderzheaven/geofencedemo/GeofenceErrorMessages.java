package com.coderzheaven.geofencedemo;


public class GeofenceErrorMessages {
}
